# coding=utf-8
"""
Integration tests for acnportal.
"""
