from .data_client import DataClient

del data_client
