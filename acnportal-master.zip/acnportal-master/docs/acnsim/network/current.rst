Current
===========
.. autoclass:: acnportal.acnsim.network.Current
    :members: