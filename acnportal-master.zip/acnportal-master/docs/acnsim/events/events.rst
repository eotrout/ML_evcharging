Events
======
.. autoclass:: acnportal.acnsim.events.Event
    :members:

.. autoclass:: acnportal.acnsim.events.PluginEvent
    :members:

.. autoclass:: acnportal.acnsim.events.UnplugEvent
    :members:

.. autoclass:: acnportal.acnsim.events.RecomputeEvent
    :members: